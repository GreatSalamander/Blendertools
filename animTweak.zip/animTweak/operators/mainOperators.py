import bpy

from ..functions import apply_pose
from ..functions import reset_props
from ..functions import insert_keyframe


class ApplyPose(bpy.types.Operator):
    bl_label = "Apply Pose Custom"
    bl_idname = "poselib.apply_pose_custom"

    pose_index = bpy.props.IntProperty()
    opacity = bpy.props.FloatProperty()

    def execute(self,context):
    	print(self.pose_index)
    	apply_pose(self.pose_index,self.opacity,context)
    	return({'FINISHED'})

class StoreNonZeroValue(bpy.types.Operator) :
    """ Store Non Zero Value
    """
    bl_idname = "store.non_zero_value"
    bl_label = "Store Custom Prop value"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.active_object != None and context.active_object.type == 'ARMATURE')

    def execute(self, context):
        ob = bpy.context.object
        for bone in ob.pose.bones :
            BoneCustomProp={}
            for key,value in bone.items() :
                if key!= '_RNA_UI' and value != 0 and type(value) in (int,float):
                    #ob.data.DefaultValues['%s["%s"]'%(bone.name,key)] = round(value,3)
                    print(value)
                    BoneCustomProp[key]=round(value,3)
            if len(BoneCustomProp) !=0 :
                ob.data.DefaultValues[bone.name]=BoneCustomProp

        return {'FINISHED'}


class ResetProps(bpy.types.Operator) :
    """ Reset Transfrom And Props.
    """
    bl_idname = "pose.reset_props"
    bl_label = "Reset bones transforms and custom propeties"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.active_object != None and context.mode == 'POSE')

    def execute(self, context):
        if len(bpy.context.selected_pose_bones)==0 :
            bones = bpy.context.object.pose.bones

        else :
            bones = bpy.context.selected_pose_bones

        for bone in bones :
            #0 = no keyframe inserted, 1 = keyframe inserted
            if bpy.context.scene.tool_settings.use_keyframe_insert_auto == False :
                reset_props(bone,0)
            else :
                reset_props(bone,1)

        return {'FINISHED'}

class InsertKeyFrame(bpy.types.Operator):
    """ Add key frame to selected bone on available transforms and properties
    """
    bl_idname = "pose.insert_keyframe"
    bl_label = "Insert Key Frame"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.active_object != None and context.mode == 'POSE')

    def execute(self, context):
        for bone in bpy.context.selected_pose_bones :
            insert_keyframe(bone)


        return {'FINISHED'}
